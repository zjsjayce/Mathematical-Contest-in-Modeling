*-------------------------------------*
*-------------------------------------*
*Only for CompeGPS Old version (< 6.4)*
*-------------------------------------*
*-------------------------------------*

Copy the folder garmintrack in your CompeGPS symbol folder (for example C:\Programmi\CompeGPS\symbols\).